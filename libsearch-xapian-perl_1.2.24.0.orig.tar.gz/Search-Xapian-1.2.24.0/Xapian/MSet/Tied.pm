package Search::Xapian::MSet::Tied;

use 5.006;
use strict;
use warnings;

use Search::Xapian::MSet;

our @ISA = qw(Search::Xapian::MSet);

1;
